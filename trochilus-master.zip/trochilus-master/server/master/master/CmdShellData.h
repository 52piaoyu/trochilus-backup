#pragma once

typedef void (CALLBACK *FnRemoteCmdOutput)(LPCTSTR clientid,UINT nMsg, LPVOID lpContext, LPVOID lpParameter);
