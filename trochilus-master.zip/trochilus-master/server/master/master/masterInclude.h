#pragma once

#include "master.h"

#pragma comment(lib, "master.lib")
