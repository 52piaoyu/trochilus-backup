#pragma once

typedef BOOL (*FnEventNotifyCallback)(LPCTSTR eventname, LPVOID lpParameter);
