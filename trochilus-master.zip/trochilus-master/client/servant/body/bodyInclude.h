#pragma once
//#include "Exports.h"

#pragma comment(lib, "body.lib")