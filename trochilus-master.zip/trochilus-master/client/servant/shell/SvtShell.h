#pragma once

void DeinitServantShell();
