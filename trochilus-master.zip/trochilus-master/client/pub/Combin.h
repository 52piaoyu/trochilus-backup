#pragma once 

extern BOOL CombinFile( WCHAR*, WCHAR* );